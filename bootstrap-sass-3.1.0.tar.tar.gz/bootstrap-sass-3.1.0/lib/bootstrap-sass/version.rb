module Bootstrap
  VERSION = '3.1.0.1'
  BOOTSTRAP_SHA = '9c054fd4c0db89cbbb1df3c868bafc4f2c17c3e3'
end
